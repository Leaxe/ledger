class Portion {
    name: Mate;
    value: Dollar;
}